[![GitHub stars](https://img.shields.io/github/stars/Gameye98/Black-Hydra.svg)](https://github.com/Gameye98/Black-Hydra/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/Gameye98/Black-Hydra.svg)](https://github.com/Gameye98/Black-Hydra/network/members)
[![GitHub issues](https://img.shields.io/github/issues/Gameye98/Black-Hydra.svg)](https://github.com/Gameye98/Black-Hydra/issues)
[![GitHub watchers](https://img.shields.io/github/watchers/Gameye98/Black-Hydra.svg)](https://github.com/Gameye98/Black-Hydra/watchers)
[![Python](https://img.shields.io/badge/language-Python%203-blue.svg)](https://www.python.org)
[![Bash](https://img.shields.io/badge/language-Bash-blue.svg)](https://www.gnu.org/software/bash/)
[![WTFPL](https://img.shields.io/badge/license-WTFPL-red.svg)](http://www.wtfpl.net/)
[![BlackHole Security](https://img.shields.io/badge/team-BlackHole%20Security-ocean.svg)](https://github.com/BlackHoleSecurity)
[![Gameye98/DedSecTL](https://img.shields.io/badge/author-Gameye98/DedSecTL-red.svg)](https://github.com/Gameye98)

[![ForTheBadge built-by-developers](http://ForTheBadge.com/images/badges/built-by-developers.svg)](https://github.com/Gameye98)  

[![BlackHole Security](.src/gitbhs.svg)](https://github.com/BlackHoleSecurity)

# Black Hydra
This program is just a small program to shorten brute force sessions on hydra :)
But to be more satisfying results of the brute force. You better interact directly with hydra,
without having to use this black hydra console first: ').
If you find any errors in running our program. Can chat via facebook :).
Hydra is needed for the process of this program :).

## Screenshot
<img src=".src/blhydra.png">

### Contact Me
[My FB Account](https://www.facebook.com/Gameye98)  
[My Telegram Account](https://t.me/dtlily)  
[BHS Facebook Page](https://www.facebook.com/2018336478223944/)  
[BHS Telegram Channel](https://t.me/bhs3c)  
[BHS Telegram Group](https://t.me/BHSec)